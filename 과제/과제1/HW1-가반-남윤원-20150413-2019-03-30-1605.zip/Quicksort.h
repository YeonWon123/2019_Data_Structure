#include <iostream>
#include "Customer.h"
using namespace std;

int partition(Customer a[], int first, int last);
void quicksort(Customer a[], int first, int last);
void swapElements(Customer a[], int first, int last);