#pragma once
#include <iostream>
#include "Customer.h"
using namespace std;

void insertNextItem(Customer a[], int i); // in cx3-6.cpp
void insertionSort(Customer a[], int n);